// export const baseUrl = "https://api.xzddd.com"
export const baseUrl = "https://food.wechat.sczhiyun.net"    //正式地址
// export const baseUrl = "https://test.api.xzddd.com"    //测试地址